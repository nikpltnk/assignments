
<?php 
session_start();
include("./includes/connect.php");

if($_SERVER["REQUEST_METHOD"] == "POST") {
    $assigment_id = $_POST["assigment_id"];
    $student_id = $_SESSION["user_id"];
    $uploaded_file_name = basename($_FILES["file"]["name"]);
    $target_directory = "uploads/";

    $unique_filename = uniqid() - '_'.$uploaded_file_name;
    $target_file = $target_directory .$unique_filename;

    $query = "INSERT INTO submitted_files (assigment_id, student_id, file_path) VALUES ('$assigment_id', '$student_id', '$target_file')";

    if($conn->query($query) === TRUE) {
        if(move_uploaded_file($_FILES["file"]["tap_name"], $target_file)) {
            echo "Файл загружен!";
            header("location: view_assignment.php");
        } else {
            echo "Ошибка перемещения файла";
        } 
        } else {
            echo "Ошибка добавления информации о файле в БД" . $conn->error;
        }

}

$conn->close();
?>
<!DOCTYPE html>
    <?php
        include("./templates/head.php");
    ?>
<body>
<link rel="stylesheet" href="./style/style.css">
<div class = "container">
    <h2>Отправка задания</h2>
    <?php 
    if (isset($_GET["id"])){
        $assigment_id = $_GET["id"];
        echo "<form action = 'submit_assignment.php' method='post'enctype='multipart/form-data'>'";
        echo "<input type= 'hidden' name= 'assignment_id' value='$assigment_id'>";
        echo "<label for ='file'>Добавить файл:</label> ";
        echo "<input type = 'file' id='file' name='file' required";
        echo "<button type='submit'>Отправить</button>";
        echo "</form>";
    } else {
        echo "Такого задания нет";
    }
?> 
</div>
</body>
</html>
