<?php
include("../includes/connect.php");

// Retrieve data from POST
$title = $_POST['title'];
$content = $_POST['content'];

// SQL query to insert data into news table
$sql = "INSERT INTO news (title, content) VALUES ('$title', '$content')";

// SQL
if ($conn->query($sql) === TRUE) {
    echo "Новость успешно добавлена";
} else {
    echo "Ошибка: " . $sql . "<br>" . $conn->error;
}

// Закрытие соединения
$conn->close();
?>