<?php
 //Подключение к БД
 $servername = "localhost";
 $username = "root";
 $password = "";
 $dbname = "training";

 $conn = new mysqli($servername, $username, $password, $dbname);
 // Проверка подключения
 if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
}

 // Обработка данных из формы регистрации
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT);

    // Вставка данных в таблицу пользователей
    $query = "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$password')";

    if ($conn->query($query) === TRUE) {
        header("Location: http://localhost/login.php");
        // echo "Регистрация успешна";
    } else {
         echo "Ошибка: " . $conn->error;
    }
}


$conn->close();
?>