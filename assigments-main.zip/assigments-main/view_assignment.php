<?php
session_start ();
include("./includes/connect.php");

$query =  "SELECT * FROM assigments";
$result = $conn->query($query);

$conn->close();
?>

<!DOCTYPE HTML>
    
    <h2>Список заданий</h2>
    <?php 
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<p><strong>Название:</strong> " .$row["title"] . "</p>";
            echo "<p><strong>Дедлайн:</strong> " .$row["deadline"] . "</p>";
            echo "<p><strong>Описание:</strong> " .$row["description"] . "</p>";
            echo "<a href='submit_assignment.php?id=" .$row["id"] .">Отправить задание</a>";
            echo "<hr>";
            
        }
    } else {
        echo "Нет заданий";
    }
    ?>
    <link rel="stylesheet" href="./style/style.css">
    </div>

</body>
</html>